# Direction artistique — منصة الزيتونة للعلوم الفيزيائية

## Trois pistes stylistiques

### Piste 1 — Atlas vivant
**Très brève introduction :** Une identité éditoriale contemporaine qui combine l’encre bleu nuit, le safran et un turquoise lumineux, avec des cartes asymétriques, des repères de cahier et des illustrations scientifiques. L’ensemble doit évoquer une plateforme de révision sérieuse mais énergisante, pensée pour donner envie de revenir chaque jour.

**Probabilité :** 0,047

### Piste 2 — Laboratoire solaire
**Très brève introduction :** Une interface claire et lumineuse, inspirée des carnets de laboratoire, avec papier ivoire, diagrammes fins et accents orange-cuivre. L’émotion recherchée est celle d’une découverte calme, précise et rassurante.

**Probabilité :** 0,083

### Piste 3 — Orbite néon
**Très brève introduction :** Une direction plus immersive et nocturne, avec constellations, lueurs cyan et modules flottants pour rappeler les champs, les ondes et l’exploration spatiale. Elle reste réservée à cette piste afin de conserver une alternative plus éditoriale et plus chaleureuse.

**Probabilité :** 0,019

## Approche retenue — Atlas vivant

### Design Movement
**Éditorial digital arabe contemporain**, enrichi de références aux cahiers quadrillés, à la cartographie et aux schémas de physique. L’interface reste noble et structurée, mais ses couleurs d’accent et ses micro-interactions parlent directement aux élèves.

### Core Principles
1. **Apprendre par étapes visibles :** chaque section doit matérialiser une progression claire, du niveau à la ressource puis à l’action.
2. **Sérieux sans rigidité :** la typographie et les contrastes restent académiques, tandis que les cartes, les pictogrammes et les animations apportent de l’élan.
3. **Asymétrie maîtrisée :** les grands blocs évitent l’empilement centré et utilisent des colonnes décalées, des rails latéraux et des repères éditoriaux.
4. **Densité utile :** chaque élément visuel doit aider à choisir, comprendre ou commencer une activité ; pas de décoration gratuite.

### Color Philosophy
Le **bleu encre** installe la concentration et la confiance. Le **safran** reprend l’héritage de la plateforme existante et signale les actions importantes. Le **turquoise minéral** apporte une énergie plus jeune et identifie les notions, les succès et les éléments interactifs. Le fond ivoire ponctuel sert de respiration visuelle afin d’éviter l’effet de tunnel nocturne tout en gardant une identité forte.

### Layout Paradigm
Une composition en **atlas à deux rythmes** : un hero en deux colonnes, avec l’accroche et les actions dans un rail principal tandis qu’un panneau de progression et une visualisation scientifique occupent le rail secondaire ; les sections suivantes alternent bandes foncées, cartes décalées et modules pleine largeur. Le contenu est aligné à droite en arabe, mais les repères visuels et les lignes de lecture créent une trajectoire naturelle de haut en bas.

### Signature Elements
- Un **fil de progression vertical safran** qui relie les étapes et niveaux.
- Des **pastilles orbitales** et petits schémas de vecteurs intégrés aux cartes.
- Des surfaces de cartes avec **quadrillage très discret**, comme une page de cahier scientifique premium.

### Interaction Philosophy
Chaque interaction doit faire sentir une avancée : les boutons sont courts, explicites et réactifs ; les cartes révèlent leur action au survol ; les onglets et filtres donnent un retour immédiat sans interrompre la lecture. Les éléments non disponibles affichent un message clair et respectueux plutôt qu’un faux parcours.

### Animation
Les apparitions de sections utilisent un fondu court avec translation verticale légère, décalée de 40 à 70 ms par groupe. Les cartes montent de quelques pixels au survol avec une ombre plus profonde et un accent safran ; les icônes orbitales tournent lentement uniquement dans les zones décoratives. Aucun mouvement ne doit dépasser 300 ms pour les interactions courantes, et toutes les animations non essentielles sont désactivées pour `prefers-reduced-motion`.

### Typography System
- **Titres :** `Noto Kufi Arabic`, poids 700–900, pour un dessin compact, contemporain et très lisible en arabe.
- **Texte et interface :** `Tajawal`, poids 400–700, pour la lecture longue et les boutons.
- **Chiffres et repères latins :** `Space Grotesk`, poids 600–700, en petites touches pour les scores, durées et niveaux.
- Hiérarchie : titres de hero très contrastés, sous-titres aérés, labels en capitales espacées et textes de cartes limités à deux ou trois lignes.

### Brand Essence
**La plateforme de sciences physiques qui transforme la révision en parcours clair, visuel et motivant pour les collégiens et lycéens.**

Personnalité : **précise, stimulante, bienveillante**.

### Brand Voice
Les titres sont directs et encourageants, les CTA sont des verbes d’action courts, et les microcopies parlent comme un professeur qui donne confiance sans infantiliser.

Exemples :
- « ابدأ من حيث أنت، وتقدّم خطوة بخطوة »
- « اختر مستواك، ثم دع الفضول يقودك »

### Wordmark & Logo
Le symbole est un **compas scientifique stylisé** : une orbite circulaire ouverte encadre une étoile à quatre branches, tandis qu’une petite flèche indique la progression. Le signe doit fonctionner seul dans la navigation et le favicon, sans écrire le nom de la marque dans une police par défaut.

### Signature Brand Color
**Safran d’Atlas — `#E8B84A`**. Un or chaud, moins luxueux et plus énergique que l’or métallique de la page source ; il garde le lien avec l’identité existante tout en signalant l’apprentissage actif.

## Règle de décision
Avant chaque choix visuel, vérifier : **« Est-ce que cela renforce ou dilue l’idée d’un atlas scientifique vivant, précis et motivant ? »**
